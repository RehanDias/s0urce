!! Updated as of version 1.0.692.843

FOR AUTOMATION DEVELOPERS:
This file explains how to disable built-in protections ("Disable Robux", "Anti Scam", and "Verify Teleports") across all games on an instance.


"Disable Robux":
	Make a file named "allowrobux" in this directory and set the content to "*".

"Anti Scam":
	Make a file named "disableantiscam" in this directory and set the content to "*".

"Verify Teleports":
	Make a file named "allowteleports" in this directory and set the content to "*".

FYI: The file content should literally just be that single asterisk (*). Please do NOT include the quotations.


How do I disable these features through the UI?
If you wish to manually disable them through the UI, you must not have any scripts running. This includes autoexecute and teleport queue.
Simply clear your autoexecute if you have anything in there, make sure you dont have anything queued using "queue_on_teleport", and do not execute anything before disabling the feature.


Why even have this?
These protections are important for keeping millions of our users safe. Scams target regular players, while people who actually need these features represent only about 5% of our userbase.
By requiring this extra step, we prioritize safety for the majority while still allowing advanced users to opt out if they choose to.